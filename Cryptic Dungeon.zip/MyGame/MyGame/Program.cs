namespace MyGame;

class MyForm : Form
{
    int clientSize = 800;

    public MyForm()
    {
        DoubleBuffered = true;
        Paint += (sender, args) =>
        {
            for (int i = 0; i < State.Map.GetLength(0); i++)
            {
                for (int j = 0; j < State.Map.GetLength(1); j++)
                {
                    args.Graphics.FillRectangle(State.Map[i, j] == MapCell.Wall ? Brushes.LightCoral : Brushes.Black, j * 80, i * 80, 80, 80);
                    if (State.Coins.Contains(new Point(i, j)))
                        args.Graphics.FillEllipse(Brushes.Gold, j * 80 + 20, i * 80 + 20, 40, 40);
                }
            }
            args.Graphics.FillEllipse(Brushes.Blue, State.Position.X * 80, State.Position.Y * 80, 80, 80);
        };
    }
    protected override void OnKeyDown(KeyEventArgs e)
    {
        State.MovePlayer(e);
        Invalidate();
    }
    static void Main()
    {
        var gstate = new State(States.firstMap);
        Application.Run(new MyForm { ClientSize = new Size(800, 800) });
    }
}
