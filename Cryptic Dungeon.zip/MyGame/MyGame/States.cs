﻿namespace MyGame;

class States
{
    public static readonly string firstMap = @"
##########
#   #   ##
#   #   ##
#   #   ##
#   #   ##
#   #    #
#        #
#        #
#    #   #
##########
|
8 1
8 4
8 6
1 5
5 8";
}
