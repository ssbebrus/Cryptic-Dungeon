﻿namespace MyGame;

public enum MapCell
{
    Empty,
    Wall
}